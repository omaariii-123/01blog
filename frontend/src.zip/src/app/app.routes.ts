import { Routes } from '@angular/router';

export const routes: Routes = [
  { 
    path: '', 
    loadComponent: () => import('./pages/feed/feed').then(m => m.FeedComponent) 
  },
  { 
    path: 'landing', 
    loadComponent: () => import('./pages/landing/landing').then(m => m.LandingComponent) 
  },
  { 
    path: 'profile', 
    loadComponent: () => import('./pages/user-profile/user-profile').then(m => m.UserProfileComponent) 
  },
  { 
    path: 'admin', 
    loadComponent: () => import('./pages/admin/admin').then(m => m.AdminComponent) 
  },
  { 
    path: 'login', 
    loadComponent: () => import('./pages/login/login').then(m => m.LoginComponent) 
  }
];
